 package com.chamodi.mydiarry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

public class AddNew extends AppCompatActivity {

     private ImageView icn_back, icn_camera;
     private ImageButton icn_calender;
     private EditText editText_date , editText_title, editText_description, editText_time;
     private Button btn_add_image, btn_save;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);

        icn_back = findViewById(R.id.icn_back);
        icn_camera = findViewById(R.id.icn_camera);

    }
}